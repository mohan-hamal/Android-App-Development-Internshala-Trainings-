package com.internshala.echo.adapters

import android.support.v7.widget.RecyclerView
import android.view.View
import android.view.ViewGroup

class NavigationDrawerAdapter : RecyclerView.Adapter<NavigationDrawerAdapter.NavViewHolder>(){
    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): NavViewHolder {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun getItemCount(): Int {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onBindViewHolder(p0: NavViewHolder, p1: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    class NavViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }

}