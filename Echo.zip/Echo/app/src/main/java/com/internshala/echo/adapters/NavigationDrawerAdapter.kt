package com.internshala.echo.adapters

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import com.internshala.echo.R

class NavigationDrawerAdapter : RecyclerView.Adapter<NavigationDrawerAdapter.NavViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup?, p1: Int): NavViewHolder {
        var itemView = LayoutInflater.from(parent?.context)
            .inflate(R.layout.row_custom_navigationdrawer, parent , false)
        val returnThis = NavViewHolder(itemView)
        return returnThis

    }

    override fun getItemCount(): Int {

    }

    override fun onBindViewHolder(holder : NavViewHolder? , p1: Int) {

    }

    class NavViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var icon_GET: ImageView? = null
        var text_GET: TextView? = null
        var contentHolder: RelativeLayout? = null
        init{
            icon_GET = itemView?.findViewById(R.id.icon_navdrawer)
            text_GET = itemView?.findViewById(R.id.text_navdrawer)
            contentHolder = itemView?.findViewById(R.id.navdrawer_item_content_holder)
        }
    }

}