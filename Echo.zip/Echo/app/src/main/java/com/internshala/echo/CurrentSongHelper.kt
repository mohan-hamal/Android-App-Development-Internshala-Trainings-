package com.internshala.echo

class CurrentSongHelper{
    var songArtist: String? = null

    var songTitle: String? = null

    var songPath: String? = null

    var songId: Long? = null

    var currentPosition: Int? = null

    var isPlaying: Boolean = false

    var isLoop: Boolean = false

    var isShuffle: Boolean = false

    var trackPosition: Int = 0
}