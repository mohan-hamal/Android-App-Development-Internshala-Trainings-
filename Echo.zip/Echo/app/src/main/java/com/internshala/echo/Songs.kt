package com.internshala.echo

class Songs(var songID: Long, var songTitle: String, var artist: String, var songData: String, var dateAdded: Long){

}