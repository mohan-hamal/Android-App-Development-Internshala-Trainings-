package com.example.myprofile

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class education : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_education)
    }
}
