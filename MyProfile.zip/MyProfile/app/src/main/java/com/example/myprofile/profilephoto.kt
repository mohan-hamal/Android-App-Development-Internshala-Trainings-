package com.example.myprofile

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class profilephoto : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profilephoto)
        title="Profile Photo"
    }
}
