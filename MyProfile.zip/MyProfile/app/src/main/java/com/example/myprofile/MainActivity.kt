package com.example.myprofile

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView

class MainActivity : AppCompatActivity() {

    var photo: ImageView?=null
    var edbutton: Button?=null
    var workbutton: Button?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.homescreen)
        photo=findViewById(R.id.pic)

        photo?.setOnClickListener{
            var clickintent= Intent(this@MainActivity, profilephoto:: class.java)
            startActivity(clickintent)
        }

        edbutton=findViewById(R.id.ed)

        edbutton?.setOnClickListener {
            var clickint=Intent(this@MainActivity, education::class.java)
            startActivity(clickint)
        }

        workbutton= findViewById(R.id.wrk)

        workbutton?.setOnClickListener {
            var click= Intent(this@MainActivity , workprofile::class.java)
            startActivity(click)
        }
    }
}
